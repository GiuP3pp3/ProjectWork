package it.corso.service;

import java.util.List;

import it.corso.model.Ospite;

public interface OspiteService {

	void registraOspite(Ospite ospite);
	
	Ospite getOspiteById(int id);
	
	List<Ospite> getOspite();
	
	void cancellaOspite(Ospite ospite);
}
