package it.corso.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.corso.dao.OspiteDao;
import it.corso.model.Ospite;

@Service
public class OspiteServiceImpl implements OspiteService {

	@Autowired
	private OspiteDao ospiteDao;
	
	@Override
	public void registraOspite(Ospite ospite) {
		ospiteDao.save(ospite);
	}

	@Override
	public Ospite getOspiteById(int id) {
		return ospiteDao.findById(id).get();
	}

	@Override
	public List<Ospite> getOspite() {
		return (List<Ospite>) ospiteDao.findAll();
	}

	@Override
	public void cancellaOspite(Ospite ospite) {
		ospiteDao.save(ospite);
		ospiteDao.delete(ospite);
	}

}
