package it.corso.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.corso.dao.PrenotazioneDao;
import it.corso.model.Camera;
import it.corso.model.Prenotazione;

@Service
public class PrenotazioneServiceImpl implements PrenotazioneService {

	@Autowired
	private PrenotazioneDao prenotazioneDao;
	
	/* @Autowired
	private CameraService cameraService; */
	
	@Override
	public void registraPrenotazione(Prenotazione prenotazione) {
		
		// 2 diversi tentativi falliti di impostare a true "prenotata"
		
		/* Camera camera= prenotazione.getCamera();
		camera.setPrenotata(true);
		cameraService.registraCamera(camera); */
		
		// prenotazione.getCamera().setPrenotata(true);
		prenotazioneDao.save(prenotazione);
	}

	@Override
	public Prenotazione getPrenotazioneById(int id) {
		return prenotazioneDao.findById(id).get();
	}

	@Override
	public List<Prenotazione> getPrenotazioni() {
		return (List<Prenotazione>) prenotazioneDao.findAll();
	}

	@Override
	public void cancellaPrenotazione(Prenotazione prenotazione) {
		prenotazioneDao.save(prenotazione);
		prenotazioneDao.delete(prenotazione);
	}

	@Override
	public boolean checkDate(LocalDate arrivo, LocalDate partenza) {
		if (partenza.isBefore(arrivo) || partenza.isEqual(arrivo))
			return false;
		return true;
	}
	
}
