package it.corso.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.corso.dao.CameraDao;
import it.corso.model.Camera;

@Service
public class CameraServiceImpl implements CameraService {

	@Autowired
	private CameraDao cameraDao;
	
	@Override
	public void registraCamera(Camera camera) {
		cameraDao.save(camera);
	}

	@Override
	public Camera getCameraById(int id) {
		return cameraDao.findById(id).get();
	}

	@Override
	public List<Camera> getCamere() {
		return (List<Camera>) cameraDao.findAll();
	}
	
	//tentativo fallito di impostare a true "prenotata"
	/* @Override
	   public List<Camera> getCamereLibere() {
		   return (List<Camera>) cameraDao.findAll();
	   }
	*/
	
	@Override
	public void cancellaCamera(Camera camera) {
		cameraDao.save(camera);
		cameraDao.delete(camera);
	}

}
