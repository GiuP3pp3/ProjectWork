package it.corso.service;

import java.time.LocalDate;
import java.util.List;

import it.corso.model.Prenotazione;

public interface PrenotazioneService {

	void registraPrenotazione(Prenotazione prenotazione);
	
	Prenotazione getPrenotazioneById(int id);
	
	List<Prenotazione> getPrenotazioni();
	
	void cancellaPrenotazione(Prenotazione prenotazione);
	
	boolean checkDate(LocalDate arrivo, LocalDate partenza);
}
