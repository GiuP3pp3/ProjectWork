package it.corso.service;

import java.util.List;

import it.corso.model.Camera;

public interface CameraService {

	void registraCamera(Camera camera);
	
	Camera getCameraById(int id);
	
	List<Camera> getCamera();
	
	void cancellaCamera(Camera camera);
}
