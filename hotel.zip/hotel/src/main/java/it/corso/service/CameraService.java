package it.corso.service;

import java.util.List;

import it.corso.model.Camera;

public interface CameraService {

	void registraCamera(Camera camera);
	
	Camera getCameraById(int id);
	
	List<Camera> getCamere();
	
	// tentativo fallito di impostare a true "prenotata"
	// List<Camera> getCamereLibere();
	
	void cancellaCamera(Camera camera);
}
