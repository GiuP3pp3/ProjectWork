package it.corso.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import it.corso.service.PrenotazioneService;

@Controller
@RequestMapping(path = {"/", "/index", "/home"})
public class IndexController 
{
	@Autowired
	PrenotazioneService prenotazioneService;
	
	@GetMapping
	public String getPage(Model model)
	{
	
		model.addAttribute("title", "Home Page");
		model.addAttribute("prenotazioni", prenotazioneService.getPrenotazioni());
		return "index";
	}	
	
	@PostMapping(path = "/deletePrenotazione")
	@ResponseBody
	public String deletePrenotazione(
			@RequestParam("id") String idPrenotazione)
	{
		
		prenotazioneService.cancellaPrenotazione(prenotazioneService.getPrenotazioneById(Integer.parseInt(idPrenotazione)));
		return "delete success";
		
	}
	
	@GetMapping(path = "/modificaPrenotazione")
	public String modificaPrenotazione(
			Model model,
			@RequestParam("id") int prenotazione)
	{
		
		//prenotazioneService.getPrenotazioneById(prenotazione);
		return "redirect:/modifica?id=" + prenotazione;
		
	}
}
