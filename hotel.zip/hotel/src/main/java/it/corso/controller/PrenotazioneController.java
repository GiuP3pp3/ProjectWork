package it.corso.controller;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import it.corso.model.Camera;
import it.corso.model.Ospite;
import it.corso.model.Prenotazione;
import it.corso.service.CameraService;
import it.corso.service.OspiteService;
import it.corso.service.PrenotazioneService;

@Controller
@RequestMapping(path = {"/prenotazione"})
public class PrenotazioneController 
{
	@Autowired
	PrenotazioneService prenotazioneService;
	
	@Autowired
	OspiteService ospiteService;
	
	@Autowired
	CameraService cameraService;
	
	Camera camera = new Camera();
	
	@GetMapping
	public String getPage(Model model,
			@RequestParam (name = "id", required = false) int idPrenotazione)
	{
		
	
		model.addAttribute("prenotazione",prenotazioneService.getPrenotazioneById(idPrenotazione));
		
		model.addAttribute("title", "Prenotazioni Page");
		model.addAttribute("camere", cameraService.getCamera());
		return "prenotazione";
	}
	
	@PostMapping("/salvaPrenotazione")
	public String salvaPrenotazione(
			@RequestParam("checkIn") String checkIn,
			@RequestParam("checkOut") String checkOut,
			@RequestParam("numeroOspiti") int numeroOspiti,
			@RequestParam("nome") String nome,
			@RequestParam("cognome") String cognome,
			@RequestParam("numeroDocumento") String numeroDocumento,
			@RequestParam("dataNascita") String dataNascita,
			@RequestParam("numeroStanza") int camera) //camera
			
			
	{
		LocalDate in = LocalDate.parse(checkIn);
		LocalDate out = LocalDate.parse(checkOut);
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		LocalDate nascita = LocalDate.parse(dataNascita);
		
		this.camera.setId(camera);
		
		
		
       
		
		Ospite ospite = new Ospite();
		ospite.setNome(nome);
		ospite.setCognome(cognome);
		ospite.setNumeroDocumento(numeroDocumento);
		ospite.setDataNascita(nascita);
		
		//ospiteService.registraOspite(ospite);
		
		Prenotazione prenotazione = new Prenotazione();
		prenotazione.setCheckIn(in);
		prenotazione.setCheckOut(out);
		prenotazione.setNumeroOspiti(numeroOspiti);
		prenotazione.setOspite(ospite);
		
		prenotazione.setCamera(this.camera);
		
		prenotazioneService.registraPrenotazione(prenotazione);
		return "redirect:/prenotazione";
		
	}

}