package it.corso.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import it.corso.model.Camera;
import it.corso.model.Prenotazione;
import it.corso.service.CameraService;
import it.corso.service.PrenotazioneService;

@Controller
@RequestMapping("/result")
public class ResultController 
{
	@Autowired
	PrenotazioneService prenotazioneService;
	
	@Autowired
	CameraService cameraService;
	
	
	
	@GetMapping
	public String getPage(Model model,
			@RequestParam("idPrenotazione") int idPrenotazione,
			@RequestParam("idCamera") int idCamera)
	{
	
		model.addAttribute("prenotazione", prenotazioneService.getPrenotazioneById(idPrenotazione));
		model.addAttribute("camera", cameraService.getCameraById(idCamera));
		model.addAttribute("title", "result");
		return "result";
	}	
	
}
