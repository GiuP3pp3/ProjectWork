package it.corso.controller;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import it.corso.model.Camera;
import it.corso.model.Ospite;
import it.corso.model.Prenotazione;
import it.corso.service.CameraService;
import it.corso.service.PrenotazioneService;

@Controller
@RequestMapping("/modifica")
public class ModificaController {

	@Autowired
	private PrenotazioneService prenotazioneService;
	
	@Autowired
	private CameraService cameraService;
	
	private boolean procedi;
	
	private int idPrenotazione;
	
	private Prenotazione prenotazione;
	
	@SuppressWarnings("unchecked")
	@GetMapping
	public String getPage(
			@RequestParam(name = "nocamere", required = false) String noCamere,
			@RequestParam(name = "confermata", required = false) String confermata,
			@RequestParam(name = "datesbagliate", required = false) String dateSbagliate,
			@RequestParam(name = "id") int id,
			Model model, 
			HttpSession session)
	{
		idPrenotazione = id;
		//passo comunque degli oggetti per evitare errori nella view
		prenotazione = prenotazioneService.getPrenotazioneById(id);
		List<Camera> camereDisponibili = selezionaCamereDisponibiliPerPeriodo(prenotazione.getCheckIn(), prenotazione.getCheckOut());
		//verifico se visualizzare l'errore per camere non disponibili
		boolean ciSonoCamere = noCamere != null ? false : true;
		//verifico se visualizzare il messaggio di prenotazione comfermata
		boolean prenotazioneConfermata = confermata == null ? false : true;
		
		boolean dateGiuste = dateSbagliate == null ? true : false;
		if(session.getAttribute("disponibili") != null)
		{
			camereDisponibili = (List<Camera>) session.getAttribute("disponibili");
			prenotazione = (Prenotazione) session.getAttribute("prenotazione");
			session.removeAttribute("disponibili");
			session.removeAttribute("prenotazione");
		}
		model.addAttribute("procedi", procedi);
		model.addAttribute("ciSonoCamere", ciSonoCamere);
		model.addAttribute("prenotazioneConfermata", prenotazioneConfermata);
		model.addAttribute("prenotazione", prenotazione);
		model.addAttribute("camereDisponibili", camereDisponibili);
		model.addAttribute("dateGiuste", dateGiuste);
		model.addAttribute("title", "Modifica");
		if (prenotazioneConfermata)
			return "result";
		
		return "modifica";
	}
	
	//recupero le date di arrivo e partenza che l'operatore seleziona in base alla richiesta del cliente
	@PostMapping("/checkdate")
	public String checkDateArrivoPartenza(
			@RequestParam("arrivo") String richiestaArrivo, 
			@RequestParam("partenza") String richiestaPartenza,
			HttpSession session)
	{
		//converto le stringhe in date
		LocalDate arrivo = LocalDate.parse(richiestaArrivo);
		LocalDate partenza = LocalDate.parse(richiestaPartenza);
		if (!prenotazioneService.checkDate(arrivo, partenza))
			return "redirect:/modifica?datesbagliate=y&id=" + idPrenotazione;
			
		//invoco il metodo per ottenere le camere disponibili nel periodo richiesto
		List<Camera> camereDisponibili = selezionaCamereDisponibiliPerPeriodo(arrivo, partenza);
		/*
		 * se ci sono camere disponibili per il periodo richiesto aggiungo la lista in
		 * sessione, comincio a valorizzare la prenotazione e la aggiungo in sessione
		 */
		if(camereDisponibili.size() > 0)
		{
			session.setAttribute("disponibili", camereDisponibili);
			prenotazione.setCheckIn(arrivo);
			prenotazione.setCheckOut(partenza);
			session.setAttribute("prenotazione", prenotazione);
			procedi = true;
			//ricarico la pagina normalmente
			return "redirect:/modifica?id=" + idPrenotazione;
		}
		//ricarico la pagina con indicazione di camere non disponibili
		return "redirect:/modifica?nocamere=y&id=" + idPrenotazione;
	}
	
	//metodo invocabile per verificare la disponibilità delle camere in base al periodo selezionato
	private List<Camera> selezionaCamereDisponibiliPerPeriodo(
			LocalDate richiestaArrivo, 
			LocalDate richiestaPartenza)
	{
		//ottengo tutte le camere
		List<Camera> tutteLeCamere = cameraService.getCamere();
		//creo collezione vuota di camere disponibili per il periodo richiesto
		List<Camera> camereDisponibili = new ArrayList<>();
		//aggiungo alla lista delle disponibili le sole camere che non hanno prenotazioni con periodo coincidente
		for(Camera c : tutteLeCamere)
		{
			boolean disponibile = true;
			for(Prenotazione p : c.getPrenotazioni())
				if(!richiestaArrivo.isAfter(p.getCheckOut()) && !richiestaPartenza.isBefore(p.getCheckIn()))
					if(!richiestaArrivo.isEqual(p.getCheckOut()) && !richiestaPartenza.isEqual(p.getCheckIn()))
					{
						disponibile = false;
						break;
					}
			if(disponibile)
				camereDisponibili.add(c);
			for (Camera cp : prenotazione.getCamere()) {
				if (c.getId() == cp.getId()) {
					camereDisponibili.add(cp);
					break;
				}
			}
		}
		return camereDisponibili;
	}
	
	//recupero i dati dal 2° form, completo la prenotazione e la registro nel database
	@PostMapping("/register")
	public String registraPrenotazione(
			@RequestParam("camera") int idCamera,
			@RequestParam("numeroOspiti") int numeroOspiti,
			@RequestParam("nome") String nomeOspite,
			@RequestParam("cognome") String cognomeOspite,
			@RequestParam("numeroDocumento") String numeroDocumento,
			@RequestParam("dataNascita") String dataNascita)
	{
		//creo l'oggetto ospite e ne valorizzo gli attributi
		Ospite ospite = prenotazione.getOspite();
		ospite.setNome(nomeOspite);
		ospite.setCognome(cognomeOspite);
		ospite.setNumeroDocumento(numeroDocumento);
		ospite.setDataNascita(LocalDate.parse(dataNascita));
		//recupero la camera selezionata dal database
		Camera camera = cameraService.getCameraById(idCamera);
		//finisco di impostare i dati della prenotazione
		prenotazione.setNumeroOspiti(numeroOspiti);
		prenotazione.setOspite(ospite);
		
		prenotazione.getCamere().clear();
		
		prenotazione.getCamere().add(camera);
		//calcolo il totale in base a tariffa e numero giorni
		double totale = camera.getTariffa() *
				(ChronoUnit.DAYS.between(prenotazione.getCheckIn(), prenotazione.getCheckOut()));
		prenotazione.setPrezzoTotale(totale);
		//salvo la prenotazione nel database
		prenotazioneService.registraPrenotazione(prenotazione);
		//ricarico la pagina con indicazione di avvenuta prenotazione
		procedi = false;
		return "redirect:/result?confermata=y&idPrenotazione=" + idPrenotazione + "&idCamera=" + idCamera;
	}
}