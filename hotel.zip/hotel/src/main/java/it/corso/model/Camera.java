package it.corso.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Pattern;

@Entity
@Table(name = "camera")
public class Camera implements Serializable {

	private static final long serialVersionUID = -7899112171866929520L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(name = "tipo", length = 20, nullable = false)
	@Pattern(regexp = "[a-zA-Z\\s]{2,20}")
	private String tipo;
	
	@Column(name = "posti_letto", nullable = false)
	@Digits(integer = 2, fraction = 0, message = "{error.invalidamount}")
	private int postiLetto;
	
	@Column(name = "tariffa", nullable = false)
	@Digits(integer = 4, fraction = 2, message = "{error.invalidamount}")
	private double tariffa;
	
	@Transient
	@Column(name = "stato", nullable = false) // come mappare boolean su tinyint
	private boolean stato;

	
	@OneToOne(mappedBy = "camera", cascade = CascadeType.MERGE) // mappedBy?
	private Prenotazione prenotazione;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public int getPostiLetto() {
		return postiLetto;
	}

	public void setPostiLetto(int postiLetto) {
		this.postiLetto = postiLetto;
	}

	public double getTariffa() {
		return tariffa;
	}

	public void setTariffa(double tariffa) {
		this.tariffa = tariffa;
	}

	public boolean isStato() {
		return stato;
	}

	public void setStato(boolean stato) {
		this.stato = stato;
	}
}
