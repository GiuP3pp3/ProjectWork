package it.corso.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.Valid;
import javax.validation.constraints.Pattern;

@Entity
@Table(name = "ospite")
public class Ospite implements Serializable {

	private static final long serialVersionUID = 511470899496080282L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(name = "nome", length = 50, nullable = false)
	@Pattern(regexp = "[a-zA-ZàáâäãåąčćęèéêëėįìíîïłńòóôöõøùúûüųūÿýżźñçčšžÀÁÂÄÃÅĄĆČĖĘÈÉÊËÌÍÎÏĮŁŃÒÓÔÖÕØÙÚÛÜŲŪŸÝŻŹÑßÇŒÆČŠŽ∂ð\\s,.'-]{2,50}",
			 message = "{error.charnotallowed}")
	private String nome;
	
	@Column(name = "cognome", length = 50, nullable = false)
	@Pattern(regexp = "[a-zA-ZàáâäãåąčćęèéêëėįìíîïłńòóôöõøùúûüųūÿýżźñçčšžÀÁÂÄÃÅĄĆČĖĘÈÉÊËÌÍÎÏĮŁŃÒÓÔÖÕØÙÚÛÜŲŪŸÝŻŹÑßÇŒÆČŠŽ∂ð\\s,.'-]{2,50}",
			 message = "{error.charnotallowed}")
	private String cognome;
	
	@Column(name = "numero_documento", length = 10, nullable = false)
	@Pattern(regexp = "[a-zA-Z0-9\\s]{1,10}") 
	private String numeroDocumento;
	
	@Column(name = "data_nascita", nullable = false)
	private LocalDate dataNascita;
	
	@OneToOne(mappedBy = "ospite", cascade = CascadeType.ALL) // mappedBy?
	private Prenotazione prenotazione;
	
	
	/*public Ospite(String nome, String cognome, 
			String numeroDocumento, Date dataNascita) {
		this.nome = nome;
		this.cognome = cognome;
		this.numeroDocumento = numeroDocumento;
		this.dataNascita = dataNascita;
		
	}*/
	
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCognome() {
		return cognome;
	}
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	public String getNumeroDocumento() {
		return numeroDocumento;
	}
	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}
	public LocalDate getDataNascita() {
		return dataNascita;
	}
	public void setDataNascita(LocalDate dataNascita) {
		this.dataNascita = dataNascita;
	}
}
