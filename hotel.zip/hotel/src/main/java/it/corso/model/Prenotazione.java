package it.corso.model;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.Valid;
import javax.validation.constraints.Digits;

@Entity
@Table(name = "prenotazione")
public class Prenotazione {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(name = "check_in", nullable = false) 
	private LocalDate checkIn;
	
	@Column(name = "check_out", nullable = false)
	private LocalDate checkOut;
	
	@Column(name = "numero_ospiti", nullable = false)
	@Digits(integer = 2, fraction = 0, message = "{error.invalidamount}")
	private int numeroOspiti;
	
	@Column(name = "prezzo_totale", nullable = false) //true altrimenti errore
	@Digits(integer = 4, fraction = 2, message = "{error.invalidamount}") // possibilità modifica prezzo della prenotazione per eventuali sconti
	private double prezzoTotale;
	
	@Valid
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "id_nominativo", referencedColumnName = "id")
	private Ospite ospite;
	
	@OneToOne(cascade = CascadeType.MERGE) 
	@JoinColumn(name = "id_camera", referencedColumnName = "id")
	private Camera camera;
	
	

	/*public Prenotazione(LocalDate checkIn, LocalDate checkOut, 
			int numeroOspiti) {
		this.checkIn = checkIn;
		this.checkOut = checkOut;
		this.numeroOspiti = numeroOspiti;
	}*/
	
	public Prenotazione() {
		
	}
	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public LocalDate getCheckIn() {
		return checkIn;
	}

	public void setCheckIn(LocalDate checkIn) {
		this.checkIn = checkIn;
	}

	public LocalDate getCheckOut() {
		return checkOut;
	}

	public void setCheckOut(LocalDate checkOut) {
		this.checkOut = checkOut;
	}

	public double getPrezzoTotale() {
		return prezzoTotale;
	}

	public void setPrezzoTotale(double prezzoTotale) {
		this.prezzoTotale = prezzoTotale;
	}

	public int getNumeroOspiti() {
		return numeroOspiti;
	}

	public void setNumeroOspiti(int numeroOspiti) {
		this.numeroOspiti = numeroOspiti;
	}


	public Ospite getOspite() {
		return ospite;
	}


	public void setOspite(Ospite ospite) {
		this.ospite = ospite;
	}


	public Camera getCamera() {
		return camera;
	}


	public void setCamera(Camera camera) {
		this.camera = camera;
	}
	
}
