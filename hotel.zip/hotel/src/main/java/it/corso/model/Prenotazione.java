package it.corso.model;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.Valid;
import javax.validation.constraints.Digits;

@Entity
@Table(name = "prenotazione")
public class Prenotazione  implements Serializable
{
	private static final long serialVersionUID = 7383776329322086107L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(name = "check_in", nullable = false) 
	private LocalDate checkIn;
	
	@Column(name = "check_out", nullable = false)
	private LocalDate checkOut;
	
	@Column(name = "numero_ospiti", nullable = false)
	private int numeroOspiti= 1;
	
	@Column(name = "prezzo_totale", nullable = false) //true altrimenti errore
	@Digits(integer = 4, fraction = 2, message = "{error.invalidamount}") // possibilità modifica prezzo della prenotazione per eventuali sconti
	private double prezzoTotale;
	
	@Valid
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "id_nominativo", referencedColumnName = "id")
	private Ospite ospite;
	
	@ManyToMany(cascade = CascadeType.REFRESH, fetch = FetchType.EAGER)
	@JoinTable
	(
			name = "prenotazioni_camere",
			joinColumns = @JoinColumn(name = "id_prenotazione", referencedColumnName = "id"),
			inverseJoinColumns = @JoinColumn(name = "id_camera", referencedColumnName = "id")
	)
	private List<Camera> camere = new ArrayList<>();

	public int getId() 
	{
		return id;
	}
	public void setId(int id) 
	{
		this.id = id;
	}
	public LocalDate getCheckIn() 
	{
		return checkIn;
	}
	public void setCheckIn(LocalDate checkIn) 
	{
		this.checkIn = checkIn;
	}
	public LocalDate getCheckOut() 
	{
		return checkOut;
	}
	public void setCheckOut(LocalDate checkOut) 
	{
		this.checkOut = checkOut;
	}
	public double getPrezzoTotale() 
	{
		return prezzoTotale;
	}
	public void setPrezzoTotale(double prezzoTotale) 
	{
		this.prezzoTotale = prezzoTotale;
	}
	public int getNumeroOspiti() 
	{
		return numeroOspiti;
	}
	public void setNumeroOspiti(int numeroOspiti) 
	{
		this.numeroOspiti = numeroOspiti;
	}
	public Ospite getOspite() 
	{
		return ospite;
	}
	public void setOspite(Ospite ospite) 
	{
		this.ospite = ospite;
	}
	public List<Camera> getCamere()
	{
		return camere;
	}
	public void setCamere(List<Camera> camere)
	{
		this.camere = camere;
	}
}