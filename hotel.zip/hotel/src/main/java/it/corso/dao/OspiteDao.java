package it.corso.dao;

import org.springframework.data.repository.CrudRepository;

import it.corso.model.Ospite;

public interface OspiteDao extends CrudRepository<Ospite, Integer> {

}
