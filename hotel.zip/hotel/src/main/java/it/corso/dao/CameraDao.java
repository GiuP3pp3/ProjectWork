package it.corso.dao;
import org.springframework.data.repository.CrudRepository;
import it.corso.model.Camera;

public interface CameraDao extends CrudRepository<Camera, Integer> 
{

}