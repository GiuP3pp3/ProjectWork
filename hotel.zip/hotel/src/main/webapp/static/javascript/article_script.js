$(document).ready(function()
{
    //espressioni regolari di controllo
 	const REGEX_1 = /^[a-z\xE0\xE8\xE9\xF9\xF2\xEC\x27\s']{1,50}$/i;
    const REGEX_2 = /^[a-z0-9\s]{1,10}$/i;

    //evento submit del form
    $('#clientForm').submit((event) =>
    {
        event.preventDefault();
        const nome = $('#nome').val();
        const cognome = $('#cognome').val();
        const numeroDocumento = $('#numeroDocumento').val();
        const formResult = checkData(nome, cognome, numeroDocumento);
        if(formResult[0] && formResult[1] && formResult[2])
            sendData(nome, cognome, numeroDocumento);
        else
            showErrors(formResult);
    });

    //controllo validità campi
    const checkData = (nome, cognome, numeroDocumento) =>
    {
        return new Array
        (
            REGEX_1.test(nome),
            REGEX_1.test(cognome),
            REGEX_2.test(numeroDocumento)
        );
    }

    //gestione messaggi di errore
    const showErrors = (formResult) =>
    {
        if(!formResult[0])
        {
            $('#descrError').css({'display':'block'});
            return;
        }
        if(!formResult[1])
        {
            $('#priceError').css({'display':'block'});
            return;
        }
    }

	//invio dati 
    const sendData = (description, price) =>
    {
        $.post
	    (
	      'article/saveclient',
	      {
			description:description,
	        price:price
	      },
	      function (response)
	      {
	        if (response === 'save success')
				location.href = '/bravo';
	      }
	    );
    }

    //reset dei messaggi di errore
	$('#aDescription').focusin(function ()
	{
	  $('#descrError').css({'display':'none'});
	});
	$('#aPrice').focusin(function ()
	{
	  $('#priceError').css({'display':'none'});
	});
});