$(document).ready(function(){
	$('.pulsanteCancella').each(function()
    {
        $(this).click(function()
        {
			 var domanda = confirm ("Sei sicuro di voler eliminare definitivamente questa prenotazione?");
					   if (domanda == true) 
					   {
						sendData($(this).val());
						//<a th:href="@{/deletePrenotazione(id=${prenotazione.id})}" ></a>
						}
        });
    });
		const sendData = (id) =>
    {
        $.post
	    (
	      'index/deletePrenotazione',
	      {
			id:id
	      },
	      function (response)
	      {
	        if (response === 'delete success')
				location.href = '/hotel';
	      }
	    );
    }
					});
					
					
					
/*					
function home(id) {
  var domanda = confirm("Sei sicuro di voler cancellare?");
  if (domanda === true) {
    
    
  }else{
    alert('Operazione annullata');
  }
}*/
					
		