$(document).ready(function(){
	$('.pulsanteCancella').each(function()
    {									
										
        $(this).click(function()		
        {									
            confirm($(this).val());			
        });								

    });

		const sendData = (id) =>
    {
        $.post
	    (
	      'index/deletePrenotazione',
	      {
			id:id
	      },
	      function (response)
	      {
	        if (response === 'delete success')
				location.href = '/hotel';
	      }
	    );
    }

					
	//costruzione finestra di dialogo
	window.confirm = function(id)
    {
        const buttonData = ["Conferma Eliminazione", "Ok", "Annulla"];
        //creazione elementi DOM
        let windowBox = document.createElement("div");
        let buttonBoxRow = document.createElement("div");
        let buttonBoxCol1 = document.createElement("div");
        let buttonBoxCol2 = document.createElement("div");
        let confirmBtn= document.createElement("button");
        let leaveBtn= document.createElement("button");
        //assegnazione classi elementi DOM 
        windowBox.classList.add("confirm-div");
        buttonBoxRow.classList.add("row");
        buttonBoxRow.classList.add("mt-4");
        buttonBoxCol1.classList.add("col-6");
        //TY DestinAzione VoglIa Di Esistere <3
        buttonBoxCol1.classList.add("text-center");
        buttonBoxCol2.classList.add("col-6");
        confirmBtn.classList.add("confirm-button");
        leaveBtn.classList.add("leave-button");
        //assegnazione testo elementi DOM
        windowBox.innerHTML = buttonData[0];
        confirmBtn.innerHTML = buttonData[1];
        leaveBtn.innerHTML = buttonData[2];
        //manipolazione elementi DOM
        buttonBoxCol1.appendChild(confirmBtn);
        buttonBoxCol2.appendChild(leaveBtn);
        buttonBoxRow.appendChild(buttonBoxCol1);
        buttonBoxRow.appendChild(buttonBoxCol2);
        windowBox.appendChild(buttonBoxRow);
        document.body.appendChild(windowBox);
        //assegnazione eventi button finestra di dialogo
        confirmBtn.addEventListener("click", function()
        {
           windowBox.remove();
           sendData(id);
        });
        leaveBtn.addEventListener("click", function()
        {
            windowBox.remove();
        });
    };	
});